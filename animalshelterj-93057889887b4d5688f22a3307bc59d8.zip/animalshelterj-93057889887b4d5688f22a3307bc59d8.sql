-- MySqlBackup.NET 2.0.9.2
-- Dump Time: 2019-09-29 20:43:36
-- --------------------------------------
-- Server version 5.7.26-log MySQL Community Server (GPL)

-- 
-- Create schema animalshelterj
-- 

CREATE DATABASE IF NOT EXISTS `animalshelterj` /*!40100 DEFAULT CHARACTER SET utf8 */;
Use `animalshelterj`;



/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 
-- Definition of animal
-- 

DROP TABLE IF EXISTS `animal`;
CREATE TABLE IF NOT EXISTS `animal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `age` int(11) NOT NULL,
  `breed` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `species` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table animal
-- 

/*!40000 ALTER TABLE `animal` DISABLE KEYS */;
INSERT INTO `animal`(`id`,`age`,`breed`,`gender`,`image_path`,`name`,`size`,`species`) VALUES
(1,5,'Dalmatian','Male','\\images\\animals\\Dozer.jpg','Dozer','Large','Dog'),
(11,3,'Poodle','Male','https://animals.net/wp-content/uploads/2018/07/Toy-Poodle-5-650x425.jpg','Sammy','4','Dog'),
(2,9,'Oriental Shorthair','Female','\\images\\animals\\Missy.jpg','Missy','Medium','Cat'),
(13,30,'King','Male','https://upload.wikimedia.org/wikipedia/en/thumb/1/11/BowserNSMBUD.png/220px-BowserNSMBUD.png','Bowser','1000','Koopa'),
(12,2,'Sphynx','Female','https://static.boredpanda.com/blog/wp-content/uploads/2019/04/adorable-hairless-sphynx-kittens-46-5cb83da47e2f8__700.jpg','Electra','3','Cat'),
(14,4,'Brown','Male','https://www.ripleys.com/wp-content/uploads/2018/11/koala-thumb-1140x630.jpg','Marcel','20','Koala');
/*!40000 ALTER TABLE `animal` ENABLE KEYS */;

-- 
-- Definition of foster
-- 

DROP TABLE IF EXISTS `foster`;
CREATE TABLE IF NOT EXISTS `foster` (
  `id` int(11) NOT NULL,
  `animal_name` varchar(255) DEFAULT NULL,
  `animal_type` varchar(255) DEFAULT NULL,
  `estimated_date_of_birth` date DEFAULT NULL,
  `foster_description` varchar(255) DEFAULT NULL,
  `foster_start` date DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table foster
-- 

/*!40000 ALTER TABLE `foster` DISABLE KEYS */;
INSERT INTO `foster`(`id`,`animal_name`,`animal_type`,`estimated_date_of_birth`,`foster_description`,`foster_start`,`image_path`) VALUES
(4,'Chubaka','Wolf','2016-02-09','Fun loving wolf','2019-09-23','/images/fosters/wolf.jpg'),
(5,'Nuts','Squirrel','2018-10-11','Shes a fun and cuddlie squirrel','2019-09-25','/images/fosters/squirrel.jpg'),
(6,'Spike','Raccoon','2019-01-13','Hes a raccoon!','2019-09-25','/images/fosters/raccoon.jpg'),
(7,'Adam','Bear','2011-06-17','Hes a big old very nice bear','2019-09-25','/images/fosters/bear.jpg');
/*!40000 ALTER TABLE `foster` ENABLE KEYS */;

-- 
-- Definition of hibernate_sequence
-- 

DROP TABLE IF EXISTS `hibernate_sequence`;
CREATE TABLE IF NOT EXISTS `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table hibernate_sequence
-- 

/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence`(`next_val`) VALUES
(35);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;

-- 
-- Definition of shelter
-- 

DROP TABLE IF EXISTS `shelter`;
CREATE TABLE IF NOT EXISTS `shelter` (
  `id` int(11) NOT NULL,
  `zip` int(11) DEFAULT NULL,
  `address_no` int(11) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `shelter_name` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `township` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table shelter
-- 

/*!40000 ALTER TABLE `shelter` DISABLE KEYS */;
INSERT INTO `shelter`(`id`,`zip`,`address_no`,`image_path`,`shelter_name`,`state`,`street`,`township`) VALUES
(1,8817,125,'\\images\\locations\\Edison.jpg','Edison Municipal Animal Shelter','NJ','Municipal Blvd','Edison'),
(2,7036,1811,'\\images\\locations\\Linden.jpg','Friends Of Linden Animal Shelter','NJ','Lower Rd','Linden'),
(3,7936,194,'\\images\\locations\\MtPleasant.jpg','Mount Pleasant Animal Shelter','NJ','NJ-10','East Hanover'),
(29,77055,7000,'https://lh5.googleusercontent.com/p/AF1QipPlOtfSIcK3fXY5mQSS0jB0vJMCwPR_TWBBXlUY=w240-h160-k-no','Houston Shelter','TX','Old Katy Rd.','Houston'),
(30,40018,4850,'https://s3-media2.fl.yelpcdn.com/bphoto/rjUhbDM799GiJ55HoYTbpg/ls.jpg','Louisville Shelter','KY','Old Fiddle Rd.','Louisville');
/*!40000 ALTER TABLE `shelter` ENABLE KEYS */;

-- 
-- Definition of staff
-- 

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `id` int(11) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table staff
-- 

/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff`(`id`,`image_path`,`name`,`title`) VALUES
(1,'\\images\\staff\\Axl.jpg','Axl Sloan','Vetrinarian'),
(2,'\\images\\staff\\Jeanette.jpg','Jeanette Cano','Manager'),
(3,'\\images\\staff\\Frank.jpg','Frank Howarth','Worker'),
(4,'\\images\\staff\\Kaiya.jpg','Kaiya Collins','Adoption Facilitator'),
(31,'https://static.independent.co.uk/s3fs-public/thumbnails/image/2018/08/08/17/elon-musk.jpg?w968h681','Elon Musk','Janitor');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;

-- 
-- Definition of test
-- 

DROP TABLE IF EXISTS `test`;
CREATE TABLE IF NOT EXISTS `test` (
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table test
-- 

/*!40000 ALTER TABLE `test` DISABLE KEYS */;

/*!40000 ALTER TABLE `test` ENABLE KEYS */;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


-- Dump completed on 2019-09-29 20:43:36
-- Total time: 0:0:0:0:328 (d:h:m:s:ms)
